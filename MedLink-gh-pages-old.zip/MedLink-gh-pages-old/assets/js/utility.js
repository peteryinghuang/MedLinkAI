var aiProvider;
var GoogleAPI;
const GoogleAIVersion = '/v1beta/models/gemini-pro';
var GoogleAIHistory = {
  contents: [
    {
      "role": "user",
      "parts": [
        {
          "text": `Message from the administration team at the University of Michigan Hospital:\n\n Role: You are a medical assistant at the University of Michigan Hospital, and your name is MedLink.\n\n Job: Ask the patient for the following information STEP BY STEP. When all information are collected and the patient does not have any other questions, print out a pre-diagnosis report in the following format to the patient. Make sure ALL required information are collected before giving the report.\n # Basic Information\n 1.Name (required)\n 2. Age (required)\n 3. Sex (required)\n 4. Height in feet (optional)\n 5. Weight in pounds (optional)\n 6. Race (required) - Note: Some diseases may exhibit different symptoms among different races, and understanding this information will aid in the preliminary diagnosis.\n\n # Medical Information\n 1. Major symptom (required): Describe your main symptoms and any questions you may have.\n 2. Time span of the symptom (required): Specify how long the symptom has been present (e.g., one week, one month, etc.).\n 3. Changes and development of the symptom (required): Indicate if the symptom has worsened, improved, or remained the same.\n 4. Characteristics of the symptom (required): Provide details such as the location of pain, characteristics of the pain, pain spread, and duration.\n 5. Medication usage (required): State whether you have taken any medication. If not, indicate "No." If yes, specify when you started taking the medication and its effects.\n 6. Disease history (required): If you have no history of diseases, indicate "No." Otherwise, specify any diseases, surgeries, or injuries you have experienced.\n 7. Additional information (required): If there is no additional information, enter "No." Otherwise, provide any relevant information related to the symptom.`
        }
      ]
    },
    {
      "role": "model",
      "parts": [
        {
          "text": `Hello and welcome!\n I am MedLink, medical assistant at the University of Michigan Hospital. May I know your name?`
        }
      ]
    },
  ]
};
var GPTAPI; 
var GPTVersion;
var GPTHistory = {
  messages: [
    {
      "role": "system",
      "content": `Message from the administration team at the University of Michigan Hospital:\n\n Role: You are a medical assistant at the University of Michigan Hospital, and your name is MedLink.\n\n Job: Ask the patient for the following information STEP BY STEP. When all information are collected and the patient does not have any other questions, print out a pre-diagnosis report in the following format to the patient. Make sure ALL required information are collected before giving the report.\n # Basic Information\n 1.Name (required)\n 2. Age (required)\n 3. Sex (required)\n 4. Height in feet (optional)\n 5. Weight in pounds (optional)\n 6. Race (required) - Note: Some diseases may exhibit different symptoms among different races, and understanding this information will aid in the preliminary diagnosis.\n\n # Medical Information\n 1. Major symptom (required): Describe your main symptoms and any questions you may have.\n 2. Time span of the symptom (required): Specify how long the symptom has been present (e.g., one week, one month, etc.).\n 3. Changes and development of the symptom (required): Indicate if the symptom has worsened, improved, or remained the same.\n 4. Characteristics of the symptom (required): Provide details such as the location of pain, characteristics of the pain, pain spread, and duration.\n 5. Medication usage (required): State whether you have taken any medication. If not, indicate "No." If yes, specify when you started taking the medication and its effects.\n 6. Disease history (required): If you have no history of diseases, indicate "No." Otherwise, specify any diseases, surgeries, or injuries you have experienced.\n 7. Additional information (required): If there is no additional information, enter "No." Otherwise, provide any relevant information related to the symptom.`
    },
    {
      "role": "assistant",
      "content": `Hello and welcome!\n I am MedLink, medical assistant at the University of Michigan Hospital. May I know your name?`
    },
  ]
};

function get(selector, root = document) {
  return root.querySelector(selector);
}

function formatDate(date) {
  const h = "0" + date.getHours();
  const m = "0" + date.getMinutes();

  return `${h.slice(-2)}:${m.slice(-2)}`;
}

function random(min, max) {
  return Math.floor(Math.random() * (max - min) + min);
}

function showGeminiForm() {
  var form = document.getElementById("gemini_info");
  form.style.display = form.style.display === "none" ? "block" : "none";
}

function showGPT3_5Form() {
  var form = document.getElementById("gpt3.5_info");
  form.style.display = form.style.display === "none" ? "block" : "none";
}

function showGPT4Form() {
  var form = document.getElementById("gpt4_info");
  form.style.display = form.style.display === "none" ? "block" : "none";
}

function getVersion(id_1, id_2, isGoogleAI) {
  var version1 = document.getElementById(id_1).value;
  var version2 = document.getElementById(id_2).value;
  if (version1 === '' & version2 === '') {
    alert('API Key cannot be blank');
    return false;
  }
  if (version1 === '') {
    GPTVersion = 'gpt-4';
    GPTAPI = version2;
  } else {
    GPTVersion = 'gpt-3.5-turbo';
    GPTAPI = version1;
  }
  return true;
}

function connectGoogleAI() {
  GoogleAPI = document.getElementById('Gemini_API').value;;
  if (GoogleAPI === "") {
    alert('API Key cannot be blank');
    return;
  }
  // https://api.genai.gd.edu.kg/google
  var apiURL = "https://generativelanguage.googleapis.com" + GoogleAIVersion + "?key=" + GoogleAPI;
  fetch(apiURL, {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json'
    }
  })
  .then(response => response.json())
  .then(responseJSON => {
    if (responseJSON.error) {
      document.getElementById("Gemini_API").value = "";
      document.getElementById("error_message_gemini").innerText = responseJSON.error.message;
    } else {
      aiProvider = "Google";
      document.getElementById("chooseModel").style.display = "none";
      document.getElementById("demoChat").style.display = "block";
    }
  })
  .catch(error => {
    console.error("Error connecting to PaLM API:", error);
    document.getElementById("error_message_palm").innerText = "Error connecting to PaLM API.";
  });
}

async function startChatGoogle(userInput) {
  try {
    appendChatHistory("user", userInput);
    const requestPayload = {
      contents: GoogleAIHistory.contents
    };
    // https://api.genai.gd.edu.kg/google
    const apiURL = "https://generativelanguage.googleapis.com" + GoogleAIVersion + ":generateContent?key=" + GoogleAPI;
    const response = await fetch(apiURL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(requestPayload)
    });
    const responseJSON = await response.json();
    const generatedText = responseJSON.candidates[0].content.parts[0].text;
    appendChatHistory("model", generatedText);
    return generatedText;
  } catch (error) {
    return error;
    console.error("Error connecting to Google AI API:", error);
    throw new Error("Error connecting to Google AI API");
  }
}

function connectGPT() {
  const submitCheck = getVersion('gpt3.5_API', 'gpt4_API', false);
  if (!submitCheck) {
    return;
  }
  // https://api.genai.gd.edu.kg/openai
  const apiUrl = 'https://api.openai.com/v1/models';
  fetch(apiUrl, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${GPTAPI}`
      }
  })
      .then(response => response.json())
      .then(responseJSON => {
        if (responseJSON.error) {
          if (GPTVersion === 'gpt-3.5-turbo') {
            document.getElementById("gpt3.5_API").value = "";
            document.getElementById("error_message_gpt3_5").innerText = responseJSON.error.message;
          } else {
            document.getElementById("gpt4_API").value = "";
            document.getElementById("error_message_gpt4").innerText = responseJSON.error.message;
          }
        } else {
          aiProvider = "OpenAI";
          document.getElementById("chooseModel").style.display = "none";
          document.getElementById("demoChat").style.display = "block";
        }
      })
      .catch(error => console.error('Error:', error));
}

async function startChatGPT(userInput) {
  try {
    appendChatHistory("user", userInput);
    const requestPayload = {
      model: GPTVersion,
      messages: GPTHistory.messages
    };
    const apiURL = 'https://api.openai.com/v1/chat/completions';
    const response = await fetch(apiURL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${GPTAPI}`
      },
      body: JSON.stringify(requestPayload)
    });
    const responseJSON = await response.json();
    if (responseJSON.object === 'chat.completion' && responseJSON.choices.length > 0) {
      const assistantResponse = responseJSON.choices[0].message.content;
      appendChatHistory("assistant", assistantResponse);
      return assistantResponse;
    } else {
      throw new Error("Unexpected response from OpenAI API");
    }
  } catch (error) {
    console.error("Error connecting to OpenAI API:", error);
    throw new Error("Error connecting to OpenAI API");
  }
}


function appendChatHistory(role, text) {
  if (aiProvider === "Google") {
    GoogleAIHistory.contents.push({
      "role": role,
      "parts": [
        {
          "text": text
        }
      ]
    });
  }
  else {
    GPTHistory.messages.push({
      "role": role,
      "content": text
    });
  }
}
