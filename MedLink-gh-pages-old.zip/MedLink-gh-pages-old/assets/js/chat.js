const msgerForm = get(".msger-inputarea");
const msgerInput = get(".msger-input");
const msgerChat = get(".msger-chat");

// Icons made by Freepik from www.flaticon.com
const BOT_IMG = "https://static.gd.edu.kg/images/logo.svg";
const PERSON_IMG = "https://medlink.ly.gd.edu.kg/assets/img/user-head.svg";
const BOT_NAME = "MedLink";
const PERSON_NAME = "Me";


msgerForm.addEventListener("submit", event => {
  event.preventDefault();

  const msgText = msgerInput.value;
  if (!msgText) return;

  appendMessage(PERSON_NAME, PERSON_IMG, "right", msgText);
  msgerInput.value = "";

  botResponse(msgText);
});

function appendMessage(name, img, side, text) {
  const msgHTML = `
    <div class="msg ${side}-msg">
      <div class="msg-img" style="background-image: url(${img})"></div>

      <div class="msg-bubble">
        <div class="msg-info">
          <div class="msg-info-name">${name}</div>
          <div class="msg-info-time">${formatDate(new Date())}</div>
        </div>

        <div class="msg-text">
          ${text.split('\n').map(paragraph => `<p>${paragraph}</p>`).join('')}
        </div>
      </div>
    </div>
  `;

  msgerChat.insertAdjacentHTML("beforeend", msgHTML);
  msgerChat.scrollTop += 500;
}

function botResponse(msgText) {
  document.getElementById("submitButton").style.display = "none";
  document.getElementById("loadingImg").style.display = "block";
  document.getElementById("msger-input").readOnly = true;
  if (aiProvider === "Google") {
    startChatGoogle(msgText)
    .then(msgText => {
      appendMessage(BOT_NAME, BOT_IMG, "left", msgText);
      document.getElementById("loadingImg").style.display = "none";
      document.getElementById("submitButton").style.display = "block";
      document.getElementById("msger-input").readOnly = false;
    })
    .catch(error => {
      console.error("Error:", error);
    });
  }
  else {
    startChatGPT(msgText)
    .then(msgText => {
      appendMessage(BOT_NAME, BOT_IMG, "left", msgText);
      document.getElementById("loadingImg").style.display = "none";
      document.getElementById("submitButton").style.display = "block";
      document.getElementById("msger-input").readOnly = false;
    })
    .catch(error => {
      console.error("Error:", error);
    });
  }
}
